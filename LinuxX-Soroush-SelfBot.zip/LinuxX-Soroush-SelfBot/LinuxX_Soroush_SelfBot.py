# -*- coding: utf-8 -*-
import asyncio
import json
from pathlib import Path
from datetime import datetime
from spluslib import SplusClient

SESSION_NAME = "soroush_session"
BASE_NAME = "MATIN"

CONFIG_FILE = Path("soroush_config.json")
MESSAGES_FILE = Path("soroush_messages.json")

PERSIAN_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
LATIN_STYLE = str.maketrans({
    "A":"𝑨","B":"𝑩","C":"𝑪","D":"𝑫","E":"𝑬","F":"𝑭","G":"𝑮","H":"𝑯",
    "I":"𝑰","J":"𝑱","K":"𝑲","L":"𝑳","M":"𝑴","N":"𝑵","O":"𝑶","P":"𝑷",
    "Q":"𝑸","R":"𝑹","S":"𝑺","T":"𝑻","U":"𝑼","V":"𝑽","W":"𝑾","X":"𝑿",
    "Y":"𝒀","Z":"𝒁",
    "0":"𝟎","1":"𝟏","2":"𝟐","3":"𝟑","4":"𝟒","5":"𝟓","6":"𝟔","7":"𝟕","8":"𝟖","9":"𝟗",
})

client = SplusClient(SESSION_NAME)
current_name = BASE_NAME
waiting_for_name = False

def load_phone():
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            phone = str(data.get("phone", "")).strip()
            if phone:
                return phone
        except Exception:
            pass

    phone = input("شماره سروش پلاس با کد کشور (مثلاً +98912xxxxxxx): ").strip()
    CONFIG_FILE.write_text(
        json.dumps({"phone": phone}, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    print("[OK] شماره در soroush_config.json ذخیره شد.")
    return phone

def load_messages():
    if not MESSAGES_FILE.exists():
        default = {str(i): f"سلام {str(i).translate(PERSIAN_DIGITS)}" for i in range(1, 11)}
        MESSAGES_FILE.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")

    try:
        data = json.loads(MESSAGES_FILE.read_text(encoding="utf-8"))
        return {str(k): str(v) for k, v in data.items()}
    except Exception as exc:
        print(f"[MESSAGES] JSON error: {exc}")
        return {str(i): f"سلام {str(i).translate(PERSIAN_DIGITS)}" for i in range(1, 11)}

def make_name():
    time_text = datetime.now().strftime("%H:%M")
    styled_name = current_name.upper().translate(LATIN_STYLE)
    styled_time = time_text.translate(LATIN_STYLE)
    return f"{styled_name} | {styled_time}"

async def clock_loop():
    while True:
        try:
            await client.update_profile(first_name=make_name(), last_name="")
            print(f"[CLOCK] Name updated: {make_name()}")
        except Exception as exc:
            print(f"[CLOCK] Could not update profile name: {exc}")
        now = datetime.now()
        await asyncio.sleep(max(1, 60 - now.second))

@client.on_message(outgoing=True)
async def name_command(msg):
    global current_name, waiting_for_name

    text = (getattr(msg, "raw_text", None) or getattr(msg, "message", "") or "").strip()

    if text.lower() == "!name":
        waiting_for_name = True
        try:
            await msg.respond("اسم جدید را بفرست:")
            await msg.delete()
        except Exception as exc:
            print(f"[NAME] Could not handle !name: {exc}")
        return

    if waiting_for_name and text and not text.startswith("!"):
        current_name = text
        waiting_for_name = False
        try:
            await client.update_profile(first_name=make_name(), last_name="")
            await msg.delete()
            print(f"[NAME] New name: {current_name}")
        except Exception as exc:
            print(f"[NAME] Could not update profile name: {exc}")

@client.on_message(outgoing=True)
async def number_commands(msg):
    text = (getattr(msg, "raw_text", None) or getattr(msg, "message", "") or "").strip()
    normalized = text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789"))

    if normalized not in {str(i) for i in range(1, 11)}:
        return

    reply = load_messages().get(normalized)
    if reply is None:
        return

    try:
        await msg.respond(reply)
        await msg.delete()
        print(f"[COMMAND] Sent: {reply} | Deleted: {text}")
    except Exception as exc:
        print(f"[COMMAND] Could not complete command: {exc}")

async def main():
    print("=" * 48)
    print("       LinuxX | Soroush Plus Self-Bot")
    print("=" * 48)
    print("Login code may be requested on first run.")

    phone = load_phone()
    await client.start(phone)
    load_messages()

    try:
        me = await client.get_me()
        print(f"[OK] Logged in. Account: {me.get('first_name', 'Unknown')}")
    except Exception:
        print("[OK] Connected.")

    asyncio.create_task(clock_loop())
    print("[READY] Clock, !name and number commands are running.")
    print("برای خروج: Ctrl+C")
    await client.run_until_disconnected()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[STOP] Bot stopped.")
