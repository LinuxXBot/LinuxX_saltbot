#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "=============================================="
echo "   LinuxX | Soroush Self-Bot Installer"
echo "=============================================="
pkg update -y
pkg install python -y
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo
echo "[OK] Installation completed."
echo "[OK] Run with:"
echo "python LinuxX_Soroush_SelfBot.py"
