# LinuxX Soroush Plus Self-Bot

نسخه آماده برای Termux. این مخزن **Session حساب سازنده را ندارد**.

## نصب سریع

```bash
pkg install git -y
git clone YOUR_GITHUB_REPO_URL
cd LinuxX-Soroush-SelfBot
bash install.sh
python LinuxX_Soroush_SelfBot.py
```

در اولین اجرا شماره حساب خودتان را وارد کنید. Session مربوط به همان حساب روی دستگاه خودتان ساخته می‌شود.

## امکانات

- نمایش نام با فونت کج/برجسته و ساعت ۲۴ ساعته
- آپدیت ساعت هر دقیقه
- دستور `!name` برای تغییر نام
- پشتیبانی از `1` تا `10` و `۱` تا `۱۰`
- پاسخ‌ها از `soroush_messages.json`
- حذف پیام عددی بعد از پاسخ
- ذخیره شماره در `soroush_config.json`

## تغییر پاسخ‌ها

فایل `soroush_messages.json` را ویرایش کنید.

**نکته امنیتی:** فایل Session را منتشر یا برای دیگران ارسال نکنید.
